
# mypackage

This function will perform the task of returning the top-n items in an array, in descending order.
